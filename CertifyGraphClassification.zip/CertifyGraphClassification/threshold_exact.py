import numpy as np
#from tqdm import trange
import argparse
from decimal import Decimal

parser = argparse.ArgumentParser(description='Get thresholds')
parser.add_argument('--r_start', default=0, type=int, 
                    help='[r_start, r_end)')
parser.add_argument('--r_end', default=1, type=int, 
                    help='[r_start, r_end)')
parser.add_argument('--a', type=int, default=80,
                    help='alpha = a / 100')
args = parser.parse_args()

v_range = [args.r_start, args.r_end]


fn = 'MUTAG'
graph_nodes = [18, 27, 14, 21, 22, 20, 12, 16, 22, 18, 22, 19, 15, 9, 12, 10, 10, 15, 15, 9]
#graph_nodes = [6]

#graph_nodes = [9]


K = 1
a = args.a
b = 100

frac_alpha = float(a) / b
frac_beta = (1 - frac_alpha) / K
print('alpha = {}, beta = {}'.format(frac_alpha, frac_beta))
print('v =', v_range)

Z = K * 100
hZ = K * 50
tZ = K * 10

alpha = a * K
beta = b - a
print('alpha = {}, beta = {}'.format(alpha, beta))

for graph_idx in range(len(graph_nodes)):

	global_d = graph_nodes[graph_idx] ** 2 - graph_nodes[graph_idx]

	print('global_d:', global_d)

	fp = open('thresholds/{}/testgraph_{}_frac_{}_exact.txt'.format(fn, graph_idx, frac_alpha), 'w')
	fp.write('r\trho_r^{-1}(0.5)\n')

	for v in range(v_range[0], v_range[1]):

		half_Z = hZ * (Z ** (global_d - 1))
		total_Z = Z ** global_d
		complete_cnt = []
			
		cnt = np.load('list_counts/{}/complete_testgraph_{}_count_{}_test.npy'.format(fn, graph_idx, v))
		#cnt = np.load('list_counts/{}/complete_count_{}_{}.npy'.format(fn, v, p))
		complete_cnt += list(cnt)
		

		raw_cnt = 0
		outcome = []
		for ((m, n), c) in complete_cnt:
			outcome.append((
				# likelihood ratio x flips m, x bar flips n
				# and then count, m, n
				(alpha ** (n - m)) * (beta ** (m - n)), c, m, n
			))
			if m != n:	
				outcome.append((
					(alpha ** (m - n)) * (beta ** (n - m)), c, n, m
				))

			raw_cnt += c
			if m != n:
				raw_cnt += c

		print(v, raw_cnt, raw_cnt - (K+1) ** global_d)
		# continue
		outcome = sorted(outcome, key = lambda x: -x[0])

		# the given probability
		p_given = 0
		
		print('#nonzero:', len(outcome))
		print('half_Z:', half_Z)

		for i in range(len(outcome)):
			ratio, cnt, m, n = outcome[i]
			p = (alpha ** (global_d - m)) * (beta ** m)
			q = (alpha ** (global_d - n)) * (beta ** n)
			q_delta = q * cnt

			if q_delta < half_Z:
				half_Z -= q_delta
				p_delta = p * cnt
				p_given += p_delta
				print(p_given)
			else:
				p_delta = p * Decimal(half_Z) / Decimal(q)
				p_given += p_delta
				print('half_Z:', Decimal(half_Z))
				print(p_delta)
				print(p_given)
				break
			

		print(p_given, total_Z)
		p_given /= total_Z

		# print('v = {}, p_given > {}'.format(v, p_given))
		fp.write('{}\t{}\n'.format(v, p_given))

	fp.close()

