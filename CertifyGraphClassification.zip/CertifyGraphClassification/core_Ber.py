import torch
from scipy.stats import norm, binom_test
from scipy.special import comb
import numpy as np
from math import ceil
from statsmodels.stats.proportion import proportion_confint

from torch.distributions.bernoulli import Bernoulli
import copy

import scipy.sparse as sp
import networkx as nx
from collections import defaultdict


def sparse_mx_to_torch_sparse_tensor(sparse_mx):
    """Convert a scipy sparse matrix to a torch sparse tensor."""
    sparse_mx = sparse_mx.tocoo().astype(np.float32)
    indices = torch.from_numpy(
        np.vstack((sparse_mx.row, sparse_mx.col)).astype(np.int64))
    values = torch.from_numpy(sparse_mx.data)
    shape = torch.Size(sparse_mx.shape)
    return torch.sparse.FloatTensor(indices, values, shape)


class Smooth_Ber(object):

    """A smoothed classifier g """

    # to abstain, Smooth_Ber returns this int
    ABSTAIN = -1

    def __init__(self, base_classifier: torch.nn.Module, num_classes: int, prob: float, graphs: torch.tensor, cuda: bool):
        """
        :param base_classifier: maps from [batch x channel x height x width] to [batch x num_classes]
        :param num_classes:
        :param prob: the probability binary vector keeps the original value 
        """
        self.base_classifier = base_classifier
        self.num_classes = num_classes
        self.prob = prob
        self.graphs = graphs
        self.cuda = cuda
        if self.cuda:
            self.m = Bernoulli(torch.tensor([self.prob]).cuda())
        else:
            self.m = Bernoulli(torch.tensor([self.prob]))


    def certify_Simu(self, x: int, n0: int, n: int, alpha: float, batch_size: int):


        self.base_classifier.eval()
        # draw samples of f(x+ epsilon)
        counts_selection = self._sample_noise_ber(x, n0, batch_size)
        # use these samples to take a guess at the top class
        cAHat = counts_selection.argmax().item()
        # draw more samples of f(x + epsilon)
        counts_estimation = self._sample_noise_ber(x, n, batch_size)
        # use these samples to estimate a lower bound on pA
        nA = counts_estimation[cAHat].item()

        counts_estimation[cAHat] = 0
        nB = counts_estimation.max()
        
        pABar = self._lower_confidence_bound(nA, n, alpha)
        pBBar = self._upper_confidence_bound(nB, n, alpha/self.num_classes)
        
        if pABar < 0.5:
            return Smooth.ABSTAIN, 0.0, 0.0
        else:
            return cAHat, pABar, pBBar


    def certify_Ber(self, x: int, n0: int, n: int, alpha: float, batch_size: int):
        """
        p(0->0) = p(1->1) = prob
        p(0->1) = p(1->0) = 1 - prob
        """
        
        """ Monte Carlo algorithm for certifying that g's prediction around x is constant within some bernoulli noise.
        With probability at least 1 - alpha, the class returned by this method will equal g(x), and g's prediction will
        robust within some bernoulli noise around x.
        :param x: the input [channel x height x width]
        :param n0: the number of Monte Carlo samples to use for selection
        :param n: the number of Monte Carlo samples to use for estimation
        :param alpha: the failure probability
        :param batch_size: batch size to use when evaluating the base classifier
        :return: (predicted class, certified radius)
                 in the case of abstention, the class will be ABSTAIN and the radius 0.
        """
        self.base_classifier.eval()
        # draw samples of f(x+ epsilon)
        counts_selection = self._sample_noise_ber(x, n0, batch_size)
        # use these samples to take a guess at the top class
        cAHat = counts_selection.argmax().item()
        # draw more samples of f(x + epsilon)
        counts_estimation = self._sample_noise_ber(x, n, batch_size)
        # use these samples to estimate a lower bound on pA
        nA = counts_estimation[cAHat].item()
        pABar = self._lower_confidence_bound(nA, n, alpha)
        # print('ppf:', norm.ppf(pABar))

        if pABar < 0.5:
            return Smooth_Ber.ABSTAIN, 0.0
        else:
            return cAHat, pABar
            
            # radius = self.prob * norm.ppf(pABar)
            # return cAHat, radius


    def predict_Ber(self, x: int, n: int, alpha: float, batch_size: int):
        """ Monte Carlo algorithm for evaluating the prediction of g at x.  With probability at least 1 - alpha, the
        class returned by this method will equal g(x).
        This function uses the hypothesis test described in https://arxiv.org/abs/1610.03944
        for identifying the top category of a multinomial distribution.
        :param x: the input [channel x height x width]
        :param n: the number of Monte Carlo samples to use
        :param alpha: the failure probability
        :param batch_size: batch size to use when evaluating the base classifier
        :return: the predicted class, or ABSTAIN
        """

        self.base_classifier.eval()
        counts = self._sample_noise_ber(x, n, batch_size)
        top2 = counts.argsort()[::-1][:2]
        #print(top2)

        count1 = counts[top2[0]]
        count2 = counts[top2[1]]
        #print(count1, count2)

        if binom_test(count1, count1 + count2, p=0.5) > alpha:
            return Smooth_Ber.ABSTAIN
        else:
            return top2[0]


    def _sample_noise_ber(self, idx: int, num: int, batch_size: int):
        """ Sample the base classifier's prediction under bernoulli noisy of input x's adj vector.
        :param idx: the input index
        :param num: number of samples to collect
        :param batch_size:
        :return: an ndarray[int] of length num_classes containing the per-class counts
        """
        
        graph = copy.deepcopy(self.graphs[idx])
        # print(graph.edge_mat[0])
        # print(graph.edge_mat[1])
        
        graph_numpy = np.asarray(graph.edge_mat.transpose(1,0).numpy())
        #print(graph_numpy)
        shape = tuple(graph_numpy.max(axis=0)[:2]+1)
        adj = sp.coo_matrix((np.ones(len(graph_numpy[:,0])), (graph_numpy[:, 0], graph_numpy[:, 1])), shape=shape, dtype=graph_numpy.dtype)
        #print(adj)
        adj_mat = sparse_mx_to_torch_sparse_tensor(adj)

        if self.cuda:
            adj = adj_mat.to_dense().int().clone().detach().cuda()
            #row_idx, col_idx = np.triu_indices(adj.shape[1])
            row_idx, col_idx = np.triu_indices(adj.shape[1])
            row_idx = torch.LongTensor(row_idx).cuda()
            col_idx = torch.LongTensor(col_idx).cuda()
           
        else:
            adj = adj_mat.to_dense().int().clone().detach()
            row_idx, col_idx = np.triu_indices(adj.shape[1])
            row_idx = torch.LongTensor(row_idx)
            col_idx = torch.LongTensor(col_idx)
        #print(adj.shape)

        with torch.no_grad():

            counts = np.zeros(self.num_classes, dtype=int)

            for iter_ in range(num):
                
                if self.cuda:
                    adj_noise = torch.zeros(adj.shape, device='cuda').int()
                    rand_inputs = torch.randint_like(adj[row_idx,col_idx], low=0, high=2, device='cuda')
                else:
                    adj_noise = torch.zeros(adj.shape).int()
                    rand_inputs = torch.randint_like(adj[row_idx,col_idx], low=0, high=2)

                mask = self.m.sample(adj[row_idx,col_idx].shape).squeeze(-1).int()
                ## sample entries in the upper triangle matrix and copy them to the lower triangle matrix
                adj_noise[row_idx,col_idx] = adj[row_idx,col_idx] * mask + rand_inputs * (1 - mask)
                adj_noise = adj_noise + adj_noise.t()

                ## diagonal elements set to be 0
                ind = np.diag_indices(adj_noise.shape[0]) 
                adj_noise[ind[0],ind[1]] = adj[ind[0], ind[1]]

                # if self.cuda:
                #     adj_noise[ind[0],ind[1]] = torch.zeros(adj_noise.shape[0], device='cuda').int()
                # else:
                #     adj_noise[ind[0],ind[1]] = torch.zeros(adj_noise.shape[0]).int()

                # print('#nnz:', (adj_noise - adj.int()).sum())
                graph.edge_mat = torch.nonzero(adj_noise).t()

                # indices = torch.nonzero(adj_noise).t()
                # print(indices[0])
                # print(indices[1])
                # graph.edge_mat[0] = indices[0]
                # values = adj_noise[indices[0], indices[1]]
                # adj_noise = torch.sparse.IntTensor(indices, values, adj_noise.size())
                # graph.edge_mat = indices
                
                # print(graph.edge_mat)


                predictions = self.base_classifier([graph]).argmax(1)
                #print(predictions)
                counts[predictions.cpu().numpy()] += 1
                
            print(counts)
            return counts
            

    def _count_arr(self, arr: np.ndarray, length: int):
        counts = np.zeros(length, dtype=int)
        for idx in arr:
            counts[idx] += 1
        return counts


    def _lower_confidence_bound(self, NA: int, N: int, alpha: float):
        """ Returns a (1 - alpha) lower confidence bound on a bernoulli proportion.
        This function uses the Clopper-Pearson method.
        :param NA: the number of "successes"
        :param N: the number of total draws
        :param alpha: the confidence level
        :return: a lower bound on the binomial proportion which holds true w.p at least (1 - alpha) over the samples
        """
        return proportion_confint(NA, N, alpha=2 * alpha, method="beta")[0]


    def _upper_confidence_bound(self, NB: int, N: int, alpha: float):
        """ Returns a (1 - alpha) upper confidence bound on a bernoulli proportion.

        This function uses the Clopper-Pearson method.

        :param NB: the number of "successes"
        :param N: the number of total draws
        :param alpha: the confidence level
        :return: a upper bound on the binomial proportion which holds true w.p at least (1 - alpha) over the samples
        """
        return proportion_confint(NB, N, alpha=2 * alpha, method="beta")[1]

